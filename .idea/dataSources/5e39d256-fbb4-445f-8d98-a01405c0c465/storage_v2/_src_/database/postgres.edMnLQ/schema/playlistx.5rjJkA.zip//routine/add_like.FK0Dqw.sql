create function add_like(u_id integer, s_id integer) returns void
    language plpgsql
as
$$
    BEGIN
        INSERT INTO likes (user_id, song_id)  VALUES (u_id, s_id);
    end;
    $$;

alter function add_like(integer, integer) owner to postgres;

