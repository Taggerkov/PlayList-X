create function add_new_song() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO song VALUES (songID, songTitle, artistName, yearNo, albumTitle, ftArtist, songDuration, genreName, songLink);
    end;
    $$;

alter function add_new_song() owner to postgres;

