create function get_likes(u_id integer)
    returns TABLE(user_id integer, song_id integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY EXECUTE 'SELECT * FROM likes WHERE user_id = CAST($1 AS int)' USING u_id;
END;
$$;

alter function get_likes(integer) owner to postgres;

