create function get_playlists(user_id text)
    returns TABLE(id smallint, title character varying, ownerid smallint, creationdate date, songscount integer, ispublic boolean, totalduration integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY EXECUTE 'SELECT id, title, ownerId, DATE(creationDate), songsCount, isPublic, totalDuration FROM playlist WHERE ownerId = CAST($1 AS smallint)' USING user_id;
    RETURN QUERY EXECUTE 'SELECT id, title, ownerId, DATE(creationDate), songsCount, isPublic, totalDuration FROM playlist WHERE isPublic = true';
END;
$$;

alter function get_playlists(text) owner to postgres;

