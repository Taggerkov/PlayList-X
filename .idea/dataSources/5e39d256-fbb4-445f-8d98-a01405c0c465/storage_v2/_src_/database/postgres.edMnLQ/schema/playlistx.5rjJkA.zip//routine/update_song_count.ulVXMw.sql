create function update_song_count() returns trigger
    language plpgsql
as
$$
    BEGIN
        UPDATE Playlist
        SET songsCount = (SELECT count(song_id) FROM song, songList, Playlist WHERE Song.id=song_id and playlist_id=Playlist.id);
        RETURN NEW;
    end;
    $$;

alter function update_song_count() owner to postgres;

