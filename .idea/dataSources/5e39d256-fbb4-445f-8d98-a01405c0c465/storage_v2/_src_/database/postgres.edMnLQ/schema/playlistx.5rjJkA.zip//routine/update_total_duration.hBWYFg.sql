create function update_total_duration() returns trigger
    language plpgsql
as
$$
    BEGIN
        UPDATE Playlist
        SET totalDuration = (SELECT sum(duration) FROM song, songList WHERE Song.id=song_id);
        RETURN NEW;
    end;
    $$;

alter function update_total_duration() owner to postgres;

